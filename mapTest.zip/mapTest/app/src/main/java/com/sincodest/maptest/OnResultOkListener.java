package com.sincodest.maptest;

import android.text.StaticLayout;

/**
 * Created by Administrator on 2018/3/12.
 */

public interface OnResultOkListener {
    public void  show(int i);
}
